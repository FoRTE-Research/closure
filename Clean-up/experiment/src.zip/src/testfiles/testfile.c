
#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>


int main(int argc, char *argv[]) 
{

}